eps = 1;
while eps+1>1
    eps=eps/2;
end
eps = eps*2