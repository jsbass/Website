//Corrected C program from HW 1

#include <stdio.h>

int main(void)
{
  int sum;

  //Compute Result
  sum = 25 + 37 -19;

  //Display Result
  printf("The answer is %i\n",sum);

  return 0;
}
