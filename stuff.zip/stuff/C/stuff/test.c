#include <stdio.h>
#include <stdlib.h>

int main(int num){

    printf("%d",num*num);

    return EXIT_SUCCESS;

}
