#!/bin/bash
rdm_gfile
proj2
f
